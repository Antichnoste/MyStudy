public class H extends null {

    String nn();

    byte oo();

    public long dd() {
        return 100500;
    }
}
