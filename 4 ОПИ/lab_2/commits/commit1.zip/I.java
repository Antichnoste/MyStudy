public interface I {

    double ad();

    void bb();
}
