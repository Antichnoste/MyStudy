public class F implements K, H {

    private double a = 100.500;

    private double d = 100.500;

    public java.lang.Class qq() {
        return getClass();
    }

    public Object rr() {
        return null;
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public byte oo() {
        return 4;
    }

    public void ab() {
        return;
    }
}
