public interface K {

    Object pp();

    java.util.Set<Integer> ll();
}
