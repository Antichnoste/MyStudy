public interface H {

    String nn();

    byte oo();
}
