public class K extends null {

    Object pp();

    java.util.Set<Integer> ll();

    public byte oo() {
        return 2;
    }

    public java.lang.Class qq() {
        return getClass();
    }
}
