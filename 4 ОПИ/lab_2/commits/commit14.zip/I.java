public class I extends null {

    double ad();

    void bb();

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}
