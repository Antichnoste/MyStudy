public class I extends null {

    double ad();

    void bb();
}
