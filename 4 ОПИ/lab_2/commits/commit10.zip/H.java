public class H extends null {

    String nn();

    byte oo();
}
