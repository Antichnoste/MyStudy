public class K extends null {

    Object pp();

    java.util.Set<Integer> ll();
}
